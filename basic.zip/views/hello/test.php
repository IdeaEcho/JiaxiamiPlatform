<h1>hello	<?=$number[1];?></h1>
<?php
	echo $haha;
	echo $number[0];
?>
