<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "courses_types".
 *
 * @property string $phone
 * @property integer $typeid
 * @property string $typename
 * @property string $privilege
 *
 * @property MerchantUser $phone0
 */
class CoursesTypes extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public $privilegeA;             //去零头
    public $privilegeB;             //满减
    public $privilegeB_lower;       //满减下限
    public $privilegeB_upper;       //满减上限


    public static function tableName()
    {
        return 'courses_types';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['phone', 'typename', 'privilege'], 'required'],
            [['phone'],'match','pattern'=>'/^1[0-9]{10}$/'],
            [['typename'], 'string', 'length' => [3, 30],'message'=>'{attribute}长度不少于2'],
            [['privilege'], 'string', 'max' => 100],
//            [['privilegeA','privilegeB'],'boolean'],

        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'phone' => 'Phone',
            'typeid' => 'Typeid',
            'typename' => '菜品分类名',
            'privilege' => 'Privilege',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPhone0()
    {
        return $this->hasOne(MerchantUser::className(), ['phone' => 'phone']);
    }
}
