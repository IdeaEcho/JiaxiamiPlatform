<?php

namespace app\models;

use Yii;
use yii\web\UploadedFile;


/**
 * This is the model class for table "dishes".
 *
 * @property string $phone
 * @property integer $dishes_id
 * @property integer $types_id
 * @property string $dishes_name
 * @property string $dishes_price
 * @property integer $dishes_sales
 * @property string $dishes_photos
 * @property double $dishes_grades
 */
class Dishes extends \yii\db\ActiveRecord
{
    public $imageFile;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'dishes';
    }
    public function scenarios()
    {
        $scenarios = parent::scenarios();
        $scenarios['upload'] = ['phone', 'dishes_name', 'dishes_price','imageFile'];
        $scenarios['noupload'] = ['phone', 'dishes_name', 'dishes_price'];
        return $scenarios;
    }
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['phone', 'dishes_name', 'dishes_price'], 'required'],
            [['dishes_price'], 'number'],
            [['dishes_name'], 'string', 'length' => [3,20]],
            [['imageFile'], 'file', 'skipOnEmpty' => true, 'extensions' => 'png, jpg'],
            [['dishes_photos'], 'string', 'max' => 100]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'phone' => 'Phone',
            'dishes_id' => 'Dishes ID',
            'types_id' => 'Types ID',
            'dishes_name' => '菜品名称',
            'dishes_price' => '价格',
            'dishes_sales' => 'Dishes Sales',
            'dishes_photos' => 'Dishes Photos',
            'dishes_grades' => 'Dishes Grades',
        ];
    }
    public function upload()
    {

        if($this->imageFile->saveAs(dirname(__DIR__).'/web/dishesimg/' . $this->imageFile->baseName . '.' . $this->imageFile->extension))
        {
            return true;
        }
        else
        {
//            echo "路径错误";
            return false;
        }
    }
}
