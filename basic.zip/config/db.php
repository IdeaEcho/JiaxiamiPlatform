<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=eat_platform',
    'username' => 'root',
    'password' => 'xiaoen147',
    'charset' => 'utf8',
];
