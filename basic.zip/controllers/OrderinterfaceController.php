<?php
/**
 * Created by PhpStorm.
 * User: Andy
 * Date: 2016/5/21 0021
 * Time: 15:59
 */
namespace app\controllers;
use app\models\Temporderinterface;
use Yii;
use yii\web\Controller;
use yii\helpers\ArrayHelper;
use app\models\MeAccountInterface;
use app\models\Dishes;
use yii\helpers\Url;
class OrderinterfaceController extends Controller
{
    public $layout = false;
    public function init(){
        $this->enableCsrfValidation = false;
    }
    public function actionSetorder()
    {
        $access_token = 'a44f8138457ecb9e87daa34bd8501cb5';
        $customer_id = '15659675727';
        $table_id = '1';
        $dish_json = array(["id"=>3,"no"=>4,"name"=>"666"],["id"=>4,"no"=>4,"name"=>"669"],["id"=>5,"no"=>4,"name"=>"666"]);
        $data = array(['access_token'=>$access_token,'table_id'=>$table_id,"customer_id"=>$customer_id,'dish_json'=>$dish_json]);
        $data = json_encode($data);


        $request = Yii::$app->request;
        if($request->isPost)
        {
            $data  = $request ->post('data',$data);
            $data = json_decode($data,true);
            if($data)
            {
//                print_r($data[0]);
                $phone = MeAccountInterface::findOne(["access_token"=>$data[0]['access_token']])->phone;
                if($phone)
                {
//                    print_r($data);
                    $price = 0;
                    $dish_json = $data[0]['dish_json'];

                    foreach($dish_json as $value)
                    {
                        $temp_model=Dishes::findOne(["dishes_id"=>$value['id']]);
                        $dishes_price=$temp_model->dishes_price*$value['no'];
                        $price+=$dishes_price;
                    }
                    $order = new Temporderinterface();
                    $order->merchant_id  = isset($phone) ? $phone : null;
                    $order->table_id = isset($data[0]['table_id']) ? $data[0]['table_id'] : null;
                    $order->customer_id = isset($data[0]['customer_id']) ? $data[0]['customer_id'] : null;
                    $order->original_cost = $price;
                    $order->present_price = $price;
                    $order->order_flag = 1;
                    $order->order_time = time();
                    $order->order_favorable = isset($data[0]['order_favorable']) ?$data[0]['order_favorable']:0;
                    $order->order_dishes = json_encode($dish_json);

                    if($order->save())
                    {
                        return json_encode(array(["returnCode"=>"200"]));
                    }
                    else
                    {
                        return json_encode(array(["returnCode"=>"300"]));
                    }

                }
            }

        }
        return json_encode(array(["returnCode"=>"400"]));



    }





    /*扫描二维码后判断是否是多人点餐*/
    public function actionTablesexist()
    {
//        $access_token = 'a44f8138457ecb9e87daa34bd8501cb5';
//        $table_id = '1';
//        $data = array(["access_token"=>$access_token,"table_id"=>$table_id]);
//        $data = json_encode($data);
//        print_r($data);
        $request = Yii::$app->request;

        if($request->isPost)
        {
            $data = $request->post('data'/*,$data*/);
//            print_r($data);
            $data = json_decode($data,true);
            if($data)
            {
                $model = MeAccountInterface::findOne(["access_token"=>$data['access_token']]);
//                print_r($model);
                if($model)
                {
                    $phone = $model->phone;
                    $model= Temporderinterface::findAll(["merchant_id"=>$phone,"table_id"=>$data['table_id'],"order_flag"=>0]);
                    if($model)
                    {
                        return json_encode(array(["returnCode"=>"200"]));
                    }
                    else
                    {
                        return json_encode(array(["returnCode"=>"400"]));
                    }
                }
            }
        }
        return json_encode(array(["returnCode"=>"300"]));
    }
    /*获得菜单*/
    public function actionGetmenu()
    {
//        $access_token = 'a44f8138457ecb9e87daa34bd8501cb5';
//        $id = '1';
//        $data = array("access_token"=>$access_token);
//        $data = json_encode($data);
        $request = Yii::$app->request;
        if($request->isPost)
        {
            $data = $request->post('data'/*,$data*/);
//            print_r($data);
            $data = json_decode($data,true);
//            print_r($data);
            if($data)
            {
                $model = MeAccountInterface::findOne(["access_token"=>$data['access_token']]);
                if($model)
                {
                    $phone = $model->phone;
                    $model=Dishes::findAll(["phone"=>$phone]);
                    $returndata = ArrayHelper::toArray($model,[
                        'app\models\Dishes'=>[
                            'dishes_id',
                            'types_id',
                            'dishes_name',
                            'dishes_price',
                            'dishes_sales',
                            'dishes_photos',
                            'dishes_grades'
                        ],
                    ]);
//                    print_r($model);
//                    print_r($returndata);
                    $returndata['phone'] = $phone;
                    return json_encode($returndata);
//                    print_r($returndata);
                }
            }
        }
        return $this->redirect(Url::toRoute("site/index"));
    }
}