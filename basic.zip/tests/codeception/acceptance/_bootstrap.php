<?php
new yii\web\Application(require(dirname(__DIR__) . '/config/acceptance.php'));
