<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=jiaxiami',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];
